package java1;

import java.util.Random;
import java.util.Scanner;

public class khw20221095_mid1 {

   public static void main(String[] args) {
      
      String[] choices = {"가위", "바위", "보"};
      int maxTurns = 10; // 최대 턴 수

      Random ran = new Random();

      for (int turn = 1; turn <= maxTurns; turn++) {
         Scanner scan = new Scanner(System.in);
         System.out.print("가위, 바위, 보! >>> ");
         // 가위, 바위, 보!라는 문장을 출력하여 입력을 유도
         String player = scan.nextLine();
         // 사용자로부터 가위, 바위, 보 중 하나를 입력받아 player라는 변수에 저장
         int p1 = ran.nextInt(3);
         int p2 = ran.nextInt(3);

         String pp1 = choices[p1];
         String pp2 = choices[p2];

         System.out.println("사용자: " + pp1 + " 상대: " + pp2);

         if (p1 == p2) {
            System.out.println("비겼습니다.");
         } else {
            switch (p1) {
               case 0:
                  if (p2 == 1)
                     System.out.println("상대 승리");
                  else
                     System.out.println("사용자 승리");
                  break;
               case 1:
                  if (p2 == 2)
                     System.out.println("상대 승리");
                  else
                     System.out.println("사용자 승리");
                  break;
               case 2:
                  if (p2 == 0)
                     System.out.println("상대 승리");
                  else
                     System.out.println("사용자 승리");
                  break;
            }
         }
      }
   }
}