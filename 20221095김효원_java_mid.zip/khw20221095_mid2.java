package java1;

import java.util.Random;
import java.util.Scanner;

public class khw20221095_mid2 {

    public static void main(String[] args) {
        String[] options = {"묵", "찌", "빠"};
        Scanner scan = new Scanner(System.in);
        Random rand = new Random();

        int bowl;
        int bowl1 = 0;
        int bowl2 = 0;
        String tie = "";
        String player1Food = "";
        String player2Food = "";
        String[] choices = {"묵", "찌", "빠"};
        int maxRounds = 3; // 총 게임 횟수
        int result = 0;
        String again = "네";


        while (true) {
            try {
                System.out.print("접시 수를 입력하세요: ");
                bowl = Integer.parseInt(scan.nextLine());
                if (bowl <= 3) {
                    break;
                }
                System.out.println("접시 수는 3 이하여야 합니다.");
            } catch (NumberFormatException e) {
                System.out.println("잘못된 선택입니다");
            }
        }
        System.out.print("플레이어 1이 먹고 싶은 음식을 입력하세요: ");
        player1Food = scan.nextLine();

        System.out.print("플레이어 2가 먹고 싶은 음식을 입력하세요: ");
        player2Food = scan.nextLine();

        System.out.println("플레이어 1이 선택한 음식: " + player1Food);
        System.out.println("플레이어 2가 선택한 음식: " + player2Food);

        // 묵찌빠 게임 진행

        System.out.println("묵찌빠 게임을 시작합니다.");

        for (int round = 1; round <= maxRounds; round++) {
            System.out.println("=== Round " + round + " ===");
            System.out.println("묵 찌 빠! >>>");

            String player1Choice = scan.nextLine();

            int player2Choice = rand.nextInt(3); // 컴퓨터의 선택

            System.out.println("플레이어 1: " + player1Choice);
            System.out.println("플레이어 2: " + choices[player2Choice]);

            result = (choices[player2Choice].equals("묵") && player1Choice.equals("찌"))
                    || (choices[player2Choice].equals("찌") && player1Choice.equals("빠"))
                    || (choices[player2Choice].equals("빠") && player1Choice.equals("묵"))
                    ? 2 : (player1Choice.equals(choices[player2Choice]) ? 0 : 1);

            if (result == 0) {
                System.out.println("무승부입니다.");
            } else if (result == 1) {
                System.out.println("플레이어 1이 이겼습니다!");
                bowl1++;
            } else {
                System.out.println("플레이어 2가 이겼습니다!");
                bowl2++;
            }

            System.out.println();
        }

        if (result == 0) {
            System.out.println("한 번 더 시작!");
            while(again.equalsIgnoreCase ("네")) {
                // 게임 재시작
                bowl1 = 0;
                bowl2 = 0;

                for (int round = 1; round <= maxRounds; round++) {
                    System.out.println("=== Round " + round + " ===");
                    System.out.println("묵 찌 빠! >>>");

                    String player1Choice = scan.nextLine();

                    int player2Choice = rand.nextInt(3); // 컴퓨터의 선택

                    System.out.println("플레이어 1: " + player1Choice);
                    System.out.println("플레이어 2: " + choices[player2Choice]);

                    result = (choices[player2Choice].equals("묵") && player1Choice.equals("찌"))
                            || (choices[player2Choice].equals("찌") && player1Choice.equals("빠"))
                            || (choices[player2Choice].equals("빠") && player1Choice.equals("묵"))
                            ? 2 : (player1Choice.equals(choices[player2Choice]) ? 0 : 1);

                    if (result == 0) {
                        System.out.println("무승부입니다.");
                    } else if (result == 1) {
                        System.out.println("플레이어 1이 이겼습니다!");
                        bowl1++;
                    } else {
                        System.out.println("플레이어 2가 이겼습니다!");
                        bowl2++;
                    }

                    System.out.println();
                }

                if (result == 0) {
                    System.out.println("다시 시작하시겠습니까?");
                } else if (result == 1) {
                    System.out.println("플레이어 1이 이겼습니다. 플레이어 1의 음식이 채택됩니다.");
                    System.out.println("최종 선택된 음식: " + player1Food + "총 먹은 접시 수: " + bowl1);
                } else {
                    System.out.println("플레이어 2가 이겼습니다. 플레이어 2의 음식이 채택됩니다.");
                    System.out.println("최종 선택된 음식: " + player2Food + "총 먹은 접시 수: " + bowl2);
                }

                System.out.println("다시 시작하시겠습니까?");
                again = scan.nextLine();
            }
        } else if (result == 1) {
            System.out.println("플레이어 1이 이겼습니다. 플레이어 1의 음식이 채택됩니다.");
            System.out.println("최종 선택된 음식: " + player1Food + " 총 먹은 접시 수: " + bowl1);
        } else {
            System.out.println("플레이어 2가 이겼습니다. 플레이어 2의 음식이 채택됩니다.");
            System.out.println("최종 선택된 음식: " + player2Food + " 총 먹은 접시 수: " + bowl2);
        }
    }
}
          